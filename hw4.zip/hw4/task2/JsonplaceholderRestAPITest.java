package Task2;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.*;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import java.util.List;


public class JsonplaceholderRestAPITest {

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }

    @Test
    void testGetAlbumsEndpoint() {
        Response response = given()
                .when()
                .get("/albums")
                .then()
                .extract()
                .response();

        assertEquals(200, response.getStatusCode());

        List<Object> titles = response.jsonPath().getList("title");

        assertFalse(titles.isEmpty());

        assertTrue(titles.contains("omnis laborum odio"));
    }

    @Test
    void testGetComments() {
        Response response = given()
                .when()
                .get("/comments")
                .then()
                .extract()
                .response();

        assertTrue(response.getStatusCode() == 200);

        int commentCount = response.jsonPath().getList("$").size();
        assertTrue(commentCount >= 200);
    }

    @Test
    void testUsers() {
        Response response = given()
                .when()
                .get("/users")
                .then()
                .extract()
                .response();

        assertTrue(response.getStatusCode() == 200);


        List<Object> user = response.jsonPath().getList("findAll { user -> user.name == 'Ervin Howell' && user.username == 'Antonette' && user.address.zipcode == '90566-7771'}");

        assertTrue(user.size() > 0);
    }

    @Test
    void testComments_SpecificEmail() {
        Response response = given()
                .when()
                .get("/comments")
                .then()
                .extract()
                .response();

        assertTrue(response.getStatusCode() == 200);

        List<Object> comments = response.jsonPath().getList("findAll { comment -> comment.email.endsWith('.biz') }");
        assertTrue(comments.size() > 0);

    }

    @Test
    void testCreatingPost() {

       Response response = post();

        assertEquals(201, response.getStatusCode(), "Expected status code 201");

        assertEquals(101, response.jsonPath().getInt("id"), "Expected post id to be 101");
        assertEquals(11, response.jsonPath().getInt("userId"), "Expected user id to be 11");
        assertEquals("sunt aut facere repellat provident occaecati excepturi optio reprehenderit", response.jsonPath().getString("title"), "Expected title to match");
        assertEquals("quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto", response.jsonPath().getString("body"), "Expected body to match");
    }

    /**
     * Helper to post data
     * @return response from post
     */

    Response post() {
        String requestBody = "{"
                + "\"userId\": 11,"
                + "\"id\": 101,"
                + "\"title\": \"sunt aut facere repellat provident occaecati excepturi optio reprehenderit\","
                + "\"body\": \"quia et suscipit\\nsuscipit recusandae consequuntur expedita et cum\\nreprehenderit molestiae ut ut quas totam\\nnostrum rerum est autem sunt rem eveniet architecto\""
                + "}";

        return given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .when()
                .post("/posts")
                .then()
                .extract()
                .response();

    }


}
