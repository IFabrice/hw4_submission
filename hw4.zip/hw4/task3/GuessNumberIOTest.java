import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import static org.junit.jupiter.api.Assertions.*;


public class GuessNumberIOTest {

    Random rand;

    @BeforeEach
    void setup() {
        rand = new Random(12);
    }


    @Test
    void testGuessingNumberGame_LowerGuesses() {
        String input = "20\n30\n40\n50\n60";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setIn(in);
        System.setOut(new PrintStream(out));

        int result = GuessNumber.guessingNumberGame(rand);

        assertEquals(67, result); // 42 indicates the correct number
        assertTrue(out.toString().contains("The number is greater than"));
        assertTrue(out.toString().contains("You have exhausted 5 trials"));
    }

    @Test
    void testGuessingNumberGame_UpperGuesses() {
        String input = "70\n90\n68\n92\n95\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setIn(in);
        System.setOut(new PrintStream(out));

        int result = GuessNumber.guessingNumberGame(rand);
        assertEquals(67, result);
        assertTrue(out.toString().contains("The number is less than"));
        assertFalse(out.toString().contains("The number is greater than"));
        assertTrue(out.toString().contains("You have exhausted 5 trials"));

    }

    @Test
    void testGuessingNumberGame_GuessOnFirstTrial() {
        String input = "67\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setIn(in);
        System.setOut(new PrintStream(out));

        int result = GuessNumber.guessingNumberGame(rand);
        assertEquals(67, result);
        assertFalse(out.toString().contains("The number is less than"));
        assertFalse(out.toString().contains("The number is greater than"));
        assertFalse(out.toString().contains("You have exhausted 5 trials"));


    }

    @Test
    void testGuessingNubmerGame_OutOfRange() {
        String input = "70\n90\n68\n-1\n120\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setIn(in);
        System.setOut(new PrintStream(out));

        int result = GuessNumber.guessingNumberGame(rand);
        assertEquals(67, result);
        assertTrue(out.toString().contains("The number is less than"));
        assertTrue(out.toString().contains("The number is greater than"));
        assertTrue(out.toString().contains("You have exhausted 5 trials"));
    }

    // The following test fails because the documentation does not specify if the input number has to be an integer or not.
    // Most likely, this test fails because the expected inputs are integers and inputting a double throws an exception.

    @Test
    void testGuessingNumberGame_GuessingDoubles() {
        String input = "70\n90\n68.8\n-1\n120\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setIn(in);
        System.setOut(new PrintStream(out));

        int result = GuessNumber.guessingNumberGame(rand);
        assertEquals(67, result);
        assertTrue(out.toString().contains("The number is less than"));
        assertTrue(out.toString().contains("The number is greater than"));
        assertTrue(out.toString().contains("You have exhausted 5 trials"));
    }


}
