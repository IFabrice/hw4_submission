import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Random;
import static org.junit.jupiter.api.Assertions.*;

public class GuessNumberRandomnessTest {

    @Test
    void testGuessingNumberGame_ProbeTheRange() {
        int[] frequency = new int[100];

        double expectedFreq = 30000.0/100.0;
        double upperBound = expectedFreq + expectedFreq * .5;
        double lowerBound = expectedFreq - expectedFreq * .5;

        for (int i = 0; i < frequency.length; i++) {
            frequency[i] = 0;
        }

        Random rand = new Random(0);
        String input = "20\n30\n40\n50\n60";

        for (int i = 0; i < 30000; i++) {
            InputStream in = new ByteArrayInputStream(input.getBytes());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            System.setIn(in);
            System.setOut(new PrintStream(out));

            int result = GuessNumber.guessingNumberGame(rand);
            frequency[result - 1] += 1;
        }

        for (int i = 0; i < frequency.length; i++) {
            assertTrue(frequency[i] < upperBound && frequency[i] > lowerBound);
        }
    }


}
