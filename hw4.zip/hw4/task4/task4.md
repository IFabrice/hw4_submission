1. Link to github repo: https://github.com/IFabrice/ci-helloworld.git

2. Link to Docker repo: https://hub.docker.com/r/ifabrice/ci-helloworld/tags